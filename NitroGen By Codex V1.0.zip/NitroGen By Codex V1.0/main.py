import os
os.system("color A")
import random
from time import sleep

print(' __    __  ______  ________  _______    ______          ______   ________  __    __       ')
print('|  \  |  \|      \|        \|       \  /      \        /      \ |        \|  \  |  \      ')
print('| $$\ | $$ \$$$$$$ \$$$$$$$$| $$$$$$$\|  $$$$$$\      |  $$$$$$\| $$$$$$$$| $$\ | $$      ')
print('| $$$\| $$  | $$     | $$   | $$__| $$| $$  | $$      | $$ __\$$| $$__    | $$$\| $$      ')
print('| $$$$\ $$  | $$     | $$   | $$    $$| $$  | $$      | $$|    \| $$  \   | $$$$\ $$      ')
print('| $$\$$ $$  | $$     | $$   | $$$$$$$\| $$  | $$      | $$ \$$$$| $$$$$   | $$\$$ $$      ')
print('| $$ \$$$$ _| $$_    | $$   | $$  | $$| $$__/ $$      | $$__| $$| $$_____ | $$ \$$$$      ')
print('| $$  \$$$|   $$ \   | $$   | $$  | $$ \$$    $$       \$$    $$| $$     \| $$  \$$$      ')
print(' \$$   \$$ \$$$$$$    \$$    \$$   \$$  \$$$$$$         \$$$$$$  \$$$$$$$$ \$$   \$$      ')
print('                                                                                          ')
print('                                      BY CODEX                                            ')
print('                                        V1.0                                              ')

print('Starting in 3 seconds...')
sleep(3)

caracteres = ['a','b','c','d','e','f','g','h','i','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','0','1','2','3','4','5','6','7','8','9']

while True:
    nitrocode = ''

    for i in range(16):
        nitrocode = f"{nitrocode}{random.choice(caracteres)}"
	

    print(f"https://discord.gift/{nitrocode}")
    
    with open("nitros.txt", "a+") as nitroFile:

        nitroFile.write(f"https://discord.gift/{nitrocode} \n")

        nitroFile.close()

